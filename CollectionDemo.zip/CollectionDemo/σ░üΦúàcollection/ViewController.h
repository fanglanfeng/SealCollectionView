//
//  ViewController.h
//  封装collection
//
//  Created by 房兰峰on 16/1/1.
//  Copyright © 2016年 房兰峰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end

